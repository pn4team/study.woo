-- All In One WP Security & Firewall 4.3.6
-- MySQL dump
-- 2018-10-04 06:15:30

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_aiowps_login_activity` VALUES("1","1","admin","2018-09-18 11:33:25","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("2","1","admin","2018-09-18 11:46:43","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("3","1","admin","2018-09-25 11:11:05","0000-00-00 00:00:00","127.0.0.1","","");


DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_comments` VALUES("1","1","Коментатор WordPress","wapuu@wordpress.example","https://wordpress.org/","","2018-09-03 12:47:18","2018-09-03 09:47:18","Привіт, це коментар.
Щоби почати модерування, редагування, та видалення коментарів, будь ласка, відвідайте розділ коментарів у Майстерні.
Аватари коментаторів ідуть із <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=724 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://study.woo","yes");
INSERT INTO `wp_options` VALUES("2","home","http://study.woo","yes");
INSERT INTO `wp_options` VALUES("3","blogname","study.woo","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Просто ще один сайт на WordPress","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","1","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","andyblacknred@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:6:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:22:\"cyr3lat/cyr-to-lat.php\";i:2;s:21:\"imsanity/imsanity.php\";i:3;s:33:\"kama-spamblock/kama-spamblock.php\";i:4;s:27:\"woocommerce/woocommerce.php\";i:5;s:24:\"wordpress-seo/wp-seo.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","e-store","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","e-store","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","38590","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","0","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","Europe/Kiev","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","0","yes");
INSERT INTO `wp_options` VALUES("93","initial_db_version","38590","yes");
INSERT INTO `wp_options` VALUES("94","wp_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("95","fresh_site","1","yes");
INSERT INTO `wp_options` VALUES("96","WPLANG","uk","yes");
INSERT INTO `wp_options` VALUES("97","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("103","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("104","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","cron","a:15:{i:1538146038;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1538146966;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1538148875;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538159675;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1538168400;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538171238;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1538208021;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538214454;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538222959;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538223249;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538224475;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538224485;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538438400;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}i:1538636959;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("113","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1535980314;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("129","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("144","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("152","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("153","aio_wp_security_configs","a:88:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"y9t13745ja38h0dirf5q\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2018-09-18 09:23:40\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";}","yes");
INSERT INTO `wp_options` VALUES("163","wpseo","a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:5:\"8.1.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1535976849;}","yes");
INSERT INTO `wp_options` VALUES("164","wpseo_titles","a:65:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:23:\"post_types-post-maintax\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("165","wpseo_social","a:18:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("166","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES("167","_transient_timeout_wpseo_link_table_inaccessible","1567512849","no");
INSERT INTO `wp_options` VALUES("168","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("169","_transient_timeout_wpseo_meta_table_inaccessible","1567512849","no");
INSERT INTO `wp_options` VALUES("170","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("180","woocommerce_store_address","","yes");
INSERT INTO `wp_options` VALUES("181","woocommerce_store_address_2","","yes");
INSERT INTO `wp_options` VALUES("182","woocommerce_store_city","","yes");
INSERT INTO `wp_options` VALUES("183","woocommerce_default_country","GB","yes");
INSERT INTO `wp_options` VALUES("184","woocommerce_store_postcode","","yes");
INSERT INTO `wp_options` VALUES("185","woocommerce_allowed_countries","all","yes");
INSERT INTO `wp_options` VALUES("186","woocommerce_all_except_countries","","yes");
INSERT INTO `wp_options` VALUES("187","woocommerce_specific_allowed_countries","","yes");
INSERT INTO `wp_options` VALUES("188","woocommerce_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("189","woocommerce_specific_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("190","woocommerce_default_customer_address","geolocation","yes");
INSERT INTO `wp_options` VALUES("191","woocommerce_calc_taxes","no","yes");
INSERT INTO `wp_options` VALUES("192","woocommerce_enable_coupons","yes","yes");
INSERT INTO `wp_options` VALUES("193","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO `wp_options` VALUES("194","woocommerce_currency","GBP","yes");
INSERT INTO `wp_options` VALUES("195","woocommerce_currency_pos","left","yes");
INSERT INTO `wp_options` VALUES("196","woocommerce_price_thousand_sep",",","yes");
INSERT INTO `wp_options` VALUES("197","woocommerce_price_decimal_sep",".","yes");
INSERT INTO `wp_options` VALUES("198","woocommerce_price_num_decimals","2","yes");
INSERT INTO `wp_options` VALUES("199","woocommerce_shop_page_id","","yes");
INSERT INTO `wp_options` VALUES("200","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO `wp_options` VALUES("201","woocommerce_enable_ajax_add_to_cart","yes","yes");
INSERT INTO `wp_options` VALUES("202","woocommerce_weight_unit","kg","yes");
INSERT INTO `wp_options` VALUES("203","woocommerce_dimension_unit","cm","yes");
INSERT INTO `wp_options` VALUES("204","woocommerce_enable_reviews","yes","yes");
INSERT INTO `wp_options` VALUES("205","woocommerce_review_rating_verification_label","yes","no");
INSERT INTO `wp_options` VALUES("206","woocommerce_review_rating_verification_required","no","no");
INSERT INTO `wp_options` VALUES("207","woocommerce_enable_review_rating","yes","yes");
INSERT INTO `wp_options` VALUES("208","woocommerce_review_rating_required","yes","no");
INSERT INTO `wp_options` VALUES("209","woocommerce_manage_stock","yes","yes");
INSERT INTO `wp_options` VALUES("210","woocommerce_hold_stock_minutes","60","no");
INSERT INTO `wp_options` VALUES("211","woocommerce_notify_low_stock","yes","no");
INSERT INTO `wp_options` VALUES("212","woocommerce_notify_no_stock","yes","no");
INSERT INTO `wp_options` VALUES("213","woocommerce_stock_email_recipient","andyblacknred@gmail.com","no");
INSERT INTO `wp_options` VALUES("214","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO `wp_options` VALUES("215","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO `wp_options` VALUES("216","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO `wp_options` VALUES("217","woocommerce_stock_format","","yes");
INSERT INTO `wp_options` VALUES("218","woocommerce_file_download_method","force","no");
INSERT INTO `wp_options` VALUES("219","woocommerce_downloads_require_login","no","no");
INSERT INTO `wp_options` VALUES("220","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO `wp_options` VALUES("221","woocommerce_prices_include_tax","no","yes");
INSERT INTO `wp_options` VALUES("222","woocommerce_tax_based_on","shipping","yes");
INSERT INTO `wp_options` VALUES("223","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO `wp_options` VALUES("224","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO `wp_options` VALUES("225","woocommerce_tax_classes","Reduced rate
Zero rate","yes");
INSERT INTO `wp_options` VALUES("226","woocommerce_tax_display_shop","excl","yes");
INSERT INTO `wp_options` VALUES("227","woocommerce_tax_display_cart","excl","yes");
INSERT INTO `wp_options` VALUES("228","woocommerce_price_display_suffix","","yes");
INSERT INTO `wp_options` VALUES("229","woocommerce_tax_total_display","itemized","no");
INSERT INTO `wp_options` VALUES("230","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO `wp_options` VALUES("231","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO `wp_options` VALUES("232","woocommerce_ship_to_destination","billing","no");
INSERT INTO `wp_options` VALUES("233","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO `wp_options` VALUES("234","woocommerce_enable_guest_checkout","yes","no");
INSERT INTO `wp_options` VALUES("235","woocommerce_enable_checkout_login_reminder","no","no");
INSERT INTO `wp_options` VALUES("236","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO `wp_options` VALUES("237","woocommerce_enable_myaccount_registration","no","no");
INSERT INTO `wp_options` VALUES("238","woocommerce_registration_generate_username","yes","no");
INSERT INTO `wp_options` VALUES("239","woocommerce_registration_generate_password","yes","no");
INSERT INTO `wp_options` VALUES("240","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO `wp_options` VALUES("241","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO `wp_options` VALUES("242","woocommerce_registration_privacy_policy_text","Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("243","woocommerce_checkout_privacy_policy_text","Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("244","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("245","woocommerce_trash_pending_orders","","no");
INSERT INTO `wp_options` VALUES("246","woocommerce_trash_failed_orders","","no");
INSERT INTO `wp_options` VALUES("247","woocommerce_trash_cancelled_orders","","no");
INSERT INTO `wp_options` VALUES("248","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("249","woocommerce_email_from_name","study.woo","no");
INSERT INTO `wp_options` VALUES("250","woocommerce_email_from_address","andyblacknred@gmail.com","no");
INSERT INTO `wp_options` VALUES("251","woocommerce_email_header_image","","no");
INSERT INTO `wp_options` VALUES("252","woocommerce_email_footer_text","{site_title}","no");
INSERT INTO `wp_options` VALUES("253","woocommerce_email_base_color","#96588a","no");
INSERT INTO `wp_options` VALUES("254","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO `wp_options` VALUES("255","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO `wp_options` VALUES("256","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO `wp_options` VALUES("257","woocommerce_cart_page_id","","yes");
INSERT INTO `wp_options` VALUES("258","woocommerce_checkout_page_id","","yes");
INSERT INTO `wp_options` VALUES("259","woocommerce_myaccount_page_id","","yes");
INSERT INTO `wp_options` VALUES("260","woocommerce_terms_page_id","","no");
INSERT INTO `wp_options` VALUES("261","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("262","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("263","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO `wp_options` VALUES("264","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO `wp_options` VALUES("265","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO `wp_options` VALUES("266","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO `wp_options` VALUES("267","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO `wp_options` VALUES("268","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO `wp_options` VALUES("269","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO `wp_options` VALUES("270","woocommerce_myaccount_downloads_endpoint","downloads","yes");
INSERT INTO `wp_options` VALUES("271","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO `wp_options` VALUES("272","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO `wp_options` VALUES("273","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO `wp_options` VALUES("274","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO `wp_options` VALUES("275","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO `wp_options` VALUES("276","woocommerce_api_enabled","no","yes");
INSERT INTO `wp_options` VALUES("277","woocommerce_single_image_width","600","yes");
INSERT INTO `wp_options` VALUES("278","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO `wp_options` VALUES("279","woocommerce_checkout_highlight_required_fields","yes","yes");
INSERT INTO `wp_options` VALUES("280","woocommerce_demo_store","no","no");
INSERT INTO `wp_options` VALUES("281","_transient_woocommerce_webhook_ids","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("282","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("283","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("284","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("285","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("286","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("287","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("288","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("289","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("290","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("291","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("292","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("293","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("294","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("296","current_theme_supports_woocommerce","yes","yes");
INSERT INTO `wp_options` VALUES("297","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO `wp_options` VALUES("298","rewrite_rules","a:160:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("300","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("301","woocommerce_admin_notices","a:2:{i:0;s:7:\"install\";i:1;s:20:\"no_secure_connection\";}","yes");
INSERT INTO `wp_options` VALUES("303","default_product_cat","15","yes");
INSERT INTO `wp_options` VALUES("306","woocommerce_version","3.4.5","yes");
INSERT INTO `wp_options` VALUES("307","woocommerce_db_version","3.4.5","yes");
INSERT INTO `wp_options` VALUES("308","wpseo_sitemap_1_cache_validator","jZG4","no");
INSERT INTO `wp_options` VALUES("309","wpseo_sitemap_product_cat_cache_validator","3bYLd","no");
INSERT INTO `wp_options` VALUES("328","current_theme","estore","yes");
INSERT INTO `wp_options` VALUES("329","theme_mods_e-store","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES("330","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("331","woocommerce_maybe_regenerate_images_hash","991b1ca641921cf0f5baf7a2fe85861b","yes");
INSERT INTO `wp_options` VALUES("335","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("431","_transient_product_query-transient-version","1537172583","yes");
INSERT INTO `wp_options` VALUES("432","wpseo_sitemap_product_cache_validator","382Zp","no");
INSERT INTO `wp_options` VALUES("434","wpseo_sitemap_post_cache_validator","jZGC","no");
INSERT INTO `wp_options` VALUES("437","wpseo_sitemap_attachment_cache_validator","3Om8n","no");
INSERT INTO `wp_options` VALUES("438","_transient_product-transient-version","1537172583","yes");
INSERT INTO `wp_options` VALUES("444","product_cat_children","a:1:{i:16;a:3:{i:0;i:17;i:1;i:18;i:2;i:19;}}","yes");
INSERT INTO `wp_options` VALUES("446","_transient_wc_attribute_taxonomies","a:2:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"1\";s:14:\"attribute_name\";s:5:\"color\";s:15:\"attribute_label\";s:5:\"Color\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:1;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"2\";s:14:\"attribute_name\";s:4:\"size\";s:15:\"attribute_label\";s:4:\"Size\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}","yes");
INSERT INTO `wp_options` VALUES("452","pa_size_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("454","wpseo_sitemap_7_cache_validator","3bWD4","no");
INSERT INTO `wp_options` VALUES("455","wpseo_sitemap_pa_color_cache_validator","3bQEV","no");
INSERT INTO `wp_options` VALUES("456","wpseo_sitemap_pa_size_cache_validator","3bQEX","no");
INSERT INTO `wp_options` VALUES("457","wpseo_sitemap_8_cache_validator","3bWD6","no");
INSERT INTO `wp_options` VALUES("458","wpseo_sitemap_9_cache_validator","3bQF3","no");
INSERT INTO `wp_options` VALUES("459","wpseo_sitemap_10_cache_validator","3bQF6","no");
INSERT INTO `wp_options` VALUES("460","wpseo_sitemap_11_cache_validator","3bQF8","no");
INSERT INTO `wp_options` VALUES("470","wpseo_sitemap_12_cache_validator","3bWCj","no");
INSERT INTO `wp_options` VALUES("471","wpseo_sitemap_13_cache_validator","3bWCl","no");
INSERT INTO `wp_options` VALUES("472","wpseo_sitemap_14_cache_validator","3bWCo","no");
INSERT INTO `wp_options` VALUES("473","wpseo_sitemap_15_cache_validator","3bWCr","no");
INSERT INTO `wp_options` VALUES("474","wpseo_sitemap_16_cache_validator","3bWCu","no");
INSERT INTO `wp_options` VALUES("475","wpseo_sitemap_17_cache_validator","3bWCw","no");
INSERT INTO `wp_options` VALUES("476","wpseo_sitemap_18_cache_validator","3bWCz","no");
INSERT INTO `wp_options` VALUES("477","wpseo_sitemap_19_cache_validator","3bWCC","no");
INSERT INTO `wp_options` VALUES("478","wpseo_sitemap_20_cache_validator","3bWCF","no");
INSERT INTO `wp_options` VALUES("479","wpseo_sitemap_product_variation_cache_validator","3bYLn","no");
INSERT INTO `wp_options` VALUES("480","wpseo_sitemap_21_cache_validator","3bWCL","no");
INSERT INTO `wp_options` VALUES("481","wpseo_sitemap_22_cache_validator","3bWCN","no");
INSERT INTO `wp_options` VALUES("482","wpseo_sitemap_23_cache_validator","3bWCQ","no");
INSERT INTO `wp_options` VALUES("483","wpseo_sitemap_24_cache_validator","3bWCT","no");
INSERT INTO `wp_options` VALUES("484","wpseo_sitemap_25_cache_validator","3bWCV","no");
INSERT INTO `wp_options` VALUES("485","wpseo_sitemap_26_cache_validator","3bWCY","no");
INSERT INTO `wp_options` VALUES("486","wpseo_sitemap_27_cache_validator","3bWD2","no");
INSERT INTO `wp_options` VALUES("490","wpseo_sitemap_28_cache_validator","3bYLg","no");
INSERT INTO `wp_options` VALUES("491","wpseo_sitemap_29_cache_validator","3bYLj","no");
INSERT INTO `wp_options` VALUES("492","wpseo_sitemap_30_cache_validator","3bYLl","no");
INSERT INTO `wp_options` VALUES("493","wpseo_sitemap_31_cache_validator","3bYLq","no");
INSERT INTO `wp_options` VALUES("495","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("497","_transient_timeout_wc_product_children_7","1539764648","no");
INSERT INTO `wp_options` VALUES("498","_transient_wc_product_children_7","a:2:{s:3:\"all\";a:3:{i:0;i:21;i:1;i:22;i:2;i:23;}s:7:\"visible\";a:3:{i:0;i:21;i:1;i:22;i:2;i:23;}}","no");
INSERT INTO `wp_options` VALUES("499","_transient_timeout_wc_var_prices_7","1539764648","no");
INSERT INTO `wp_options` VALUES("500","_transient_wc_var_prices_7","{\"version\":\"1537172583\",\"f8fb694c4e457b05b27251a3d34a1a80\":{\"price\":{\"21\":\"20.00\",\"22\":\"20.00\",\"23\":\"15.00\"},\"regular_price\":{\"21\":\"20.00\",\"22\":\"20.00\",\"23\":\"15.00\"},\"sale_price\":{\"21\":\"20.00\",\"22\":\"20.00\",\"23\":\"15.00\"}}}","no");
INSERT INTO `wp_options` VALUES("501","_transient_timeout_wc_product_children_8","1539764648","no");
INSERT INTO `wp_options` VALUES("502","_transient_wc_product_children_8","a:2:{s:3:\"all\";a:4:{i:0;i:31;i:1;i:24;i:2;i:25;i:3;i:26;}s:7:\"visible\";a:4:{i:0;i:31;i:1;i:24;i:2;i:25;i:3;i:26;}}","no");
INSERT INTO `wp_options` VALUES("503","_transient_timeout_wc_var_prices_8","1539764648","no");
INSERT INTO `wp_options` VALUES("504","_transient_wc_var_prices_8","{\"version\":\"1537172583\",\"f8fb694c4e457b05b27251a3d34a1a80\":{\"price\":{\"31\":\"45.00\",\"24\":\"42.00\",\"25\":\"45.00\",\"26\":\"45.00\"},\"regular_price\":{\"31\":\"45.00\",\"24\":\"45.00\",\"25\":\"45.00\",\"26\":\"45.00\"},\"sale_price\":{\"31\":\"45.00\",\"24\":\"42.00\",\"25\":\"45.00\",\"26\":\"45.00\"}}}","no");
INSERT INTO `wp_options` VALUES("534","_transient_timeout_wc_low_stock_count","1539851605","no");
INSERT INTO `wp_options` VALUES("535","_transient_wc_low_stock_count","0","no");
INSERT INTO `wp_options` VALUES("536","_transient_timeout_wc_outofstock_count","1539851605","no");
INSERT INTO `wp_options` VALUES("537","_transient_wc_outofstock_count","0","no");
INSERT INTO `wp_options` VALUES("554","new_admin_email","andyblacknred@gmail.com","yes");
INSERT INTO `wp_options` VALUES("559","wpseo_sitemap_author_cache_validator","3i8PB","no");
INSERT INTO `wp_options` VALUES("592","_transient_timeout_wc_term_counts","1539860409","no");
INSERT INTO `wp_options` VALUES("593","_transient_wc_term_counts","a:1:{i:18;s:1:\"3\";}","no");
INSERT INTO `wp_options` VALUES("632","_est_header_logic","yes","no");
INSERT INTO `wp_options` VALUES("633","_est_header_logo","","no");
INSERT INTO `wp_options` VALUES("634","_est_header_site_name","","no");
INSERT INTO `wp_options` VALUES("635","_est_header_site_desc","","no");
INSERT INTO `wp_options` VALUES("636","_crb_email","","no");
INSERT INTO `wp_options` VALUES("637","_crb_phone","","no");
INSERT INTO `wp_options` VALUES("660","_site_transient_timeout_browser_f86ebc8df49750ff7c44a94bfd913fad","1538467867","no");
INSERT INTO `wp_options` VALUES("661","_site_transient_browser_f86ebc8df49750ff7c44a94bfd913fad","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"55.0.2883.75\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("706","_site_transient_timeout_theme_roots","1538137704","no");
INSERT INTO `wp_options` VALUES("707","_site_transient_theme_roots","a:4:{s:7:\"e-store\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("709","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:62:\"https://downloads.wordpress.org/release/uk/wordpress-4.9.8.zip\";s:6:\"locale\";s:2:\"uk\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:62:\"https://downloads.wordpress.org/release/uk/wordpress-4.9.8.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1538135908;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-18 07:42:01\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/uk.zip\";s:10:\"autoupdate\";b:1;}}}","no");
INSERT INTO `wp_options` VALUES("710","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1538135909;s:7:\"checked\";a:4:{s:7:\"e-store\";s:5:\"1.0.0\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("711","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1538135910;s:7:\"checked\";a:6:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.3.6\";s:22:\"cyr3lat/cyr-to-lat.php\";s:3:\"3.5\";s:21:\"imsanity/imsanity.php\";s:5:\"2.4.0\";s:33:\"kama-spamblock/kama-spamblock.php\";s:7:\"1.7.5.1\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.4.5\";s:24:\"wordpress-seo/wp-seo.php\";s:5:\"8.1.1\";}s:8:\"response\";a:1:{s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"8.3\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.8.3.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:11:\"woocommerce\";s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"3.4.5\";s:7:\"updated\";s:19:\"2018-09-02 22:05:38\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/translation/plugin/woocommerce/3.4.5/uk.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:5:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.3.6\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:22:\"cyr3lat/cyr-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/cyr3lat\";s:4:\"slug\";s:7:\"cyr3lat\";s:6:\"plugin\";s:22:\"cyr3lat/cyr-to-lat.php\";s:11:\"new_version\";s:3:\"3.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr3lat/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/cyr3lat.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:21:\"imsanity/imsanity.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/imsanity\";s:4:\"slug\";s:8:\"imsanity\";s:6:\"plugin\";s:21:\"imsanity/imsanity.php\";s:11:\"new_version\";s:5:\"2.4.0\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/imsanity/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/imsanity.2.4.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/imsanity/assets/icon-256x256.png?rev=1094749\";s:2:\"1x\";s:61:\"https://ps.w.org/imsanity/assets/icon-128x128.png?rev=1170755\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/imsanity/assets/banner-772x250.png?rev=900541\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"kama-spamblock/kama-spamblock.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/kama-spamblock\";s:4:\"slug\";s:14:\"kama-spamblock\";s:6:\"plugin\";s:33:\"kama-spamblock/kama-spamblock.php\";s:11:\"new_version\";s:7:\"1.7.5.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/kama-spamblock/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/kama-spamblock.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/kama-spamblock/assets/icon-256x256.png?rev=1626940\";s:2:\"1x\";s:67:\"https://ps.w.org/kama-spamblock/assets/icon-128x128.png?rev=1626940\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.4.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.4.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("721","_transient_doing_cron","1538633729.2899079322814941406250","yes");
INSERT INTO `wp_options` VALUES("722","_transient_timeout_external_ip_address_127.0.0.1","1539238527","no");
INSERT INTO `wp_options` VALUES("723","_transient_external_ip_address_127.0.0.1","91.230.25.67","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1041 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","2","_edit_lock","1535967939:1");
INSERT INTO `wp_postmeta` VALUES("4","1","_wp_old_slug","%d0%bf%d1%80%d0%b8%d0%b2%d1%96%d1%82-%d1%81%d0%b2%d1%96%d1%82");
INSERT INTO `wp_postmeta` VALUES("10","7","_sku","woo-vneck-tee");
INSERT INTO `wp_postmeta` VALUES("13","7","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("14","7","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("15","7","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("16","7","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("17","7","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("18","7","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("19","7","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("20","7","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("21","7","_weight","");
INSERT INTO `wp_postmeta` VALUES("22","7","_length","");
INSERT INTO `wp_postmeta` VALUES("23","7","_width","");
INSERT INTO `wp_postmeta` VALUES("24","7","_height","");
INSERT INTO `wp_postmeta` VALUES("25","7","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("26","7","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("27","7","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("28","7","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("29","7","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("30","7","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("31","7","_product_image_gallery","33,34");
INSERT INTO `wp_postmeta` VALUES("32","7","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("33","7","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("34","7","_stock","");
INSERT INTO `wp_postmeta` VALUES("35","7","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("36","7","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("37","7","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("38","7","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("39","7","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("40","7","_product_attributes","a:2:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}s:7:\"pa_size\";a:6:{s:4:\"name\";s:7:\"pa_size\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("41","7","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("44","8","_sku","woo-hoodie");
INSERT INTO `wp_postmeta` VALUES("47","8","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("48","8","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("49","8","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("50","8","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("51","8","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("52","8","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("53","8","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("54","8","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("55","8","_weight","");
INSERT INTO `wp_postmeta` VALUES("56","8","_length","");
INSERT INTO `wp_postmeta` VALUES("57","8","_width","");
INSERT INTO `wp_postmeta` VALUES("58","8","_height","");
INSERT INTO `wp_postmeta` VALUES("59","8","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("60","8","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("61","8","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("62","8","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("63","8","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("64","8","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("65","8","_product_image_gallery","36,37,38");
INSERT INTO `wp_postmeta` VALUES("66","8","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("67","8","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("68","8","_stock","");
INSERT INTO `wp_postmeta` VALUES("69","8","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("70","8","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("71","8","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("72","8","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("73","8","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("74","8","_product_attributes","a:2:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}s:4:\"logo\";a:6:{s:4:\"name\";s:4:\"Logo\";s:5:\"value\";s:8:\"Yes | No\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("75","8","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("78","9","_sku","woo-hoodie-with-logo");
INSERT INTO `wp_postmeta` VALUES("79","9","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("80","9","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("81","9","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("82","9","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("83","9","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("84","9","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("85","9","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("86","9","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("87","9","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("88","9","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("89","9","_weight","");
INSERT INTO `wp_postmeta` VALUES("90","9","_length","");
INSERT INTO `wp_postmeta` VALUES("91","9","_width","");
INSERT INTO `wp_postmeta` VALUES("92","9","_height","");
INSERT INTO `wp_postmeta` VALUES("93","9","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("94","9","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("95","9","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("96","9","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("97","9","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("98","9","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("99","9","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("100","9","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("101","9","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("102","9","_stock","");
INSERT INTO `wp_postmeta` VALUES("103","9","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("104","9","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("105","9","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("106","9","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("107","9","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("108","9","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("109","9","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("110","9","_price","45");
INSERT INTO `wp_postmeta` VALUES("112","10","_sku","woo-tshirt");
INSERT INTO `wp_postmeta` VALUES("113","10","_regular_price","18");
INSERT INTO `wp_postmeta` VALUES("114","10","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("115","10","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("116","10","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("117","10","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("118","10","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("119","10","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("120","10","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("121","10","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("122","10","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("123","10","_weight","");
INSERT INTO `wp_postmeta` VALUES("124","10","_length","");
INSERT INTO `wp_postmeta` VALUES("125","10","_width","");
INSERT INTO `wp_postmeta` VALUES("126","10","_height","");
INSERT INTO `wp_postmeta` VALUES("127","10","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("128","10","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("129","10","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("130","10","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("131","10","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("132","10","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("133","10","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("134","10","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("135","10","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("136","10","_stock","");
INSERT INTO `wp_postmeta` VALUES("137","10","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("138","10","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("139","10","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("140","10","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("141","10","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("142","10","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("143","10","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("144","10","_price","18");
INSERT INTO `wp_postmeta` VALUES("146","11","_sku","woo-beanie");
INSERT INTO `wp_postmeta` VALUES("147","11","_regular_price","20");
INSERT INTO `wp_postmeta` VALUES("148","11","_sale_price","18");
INSERT INTO `wp_postmeta` VALUES("149","11","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("150","11","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("151","11","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("152","11","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("153","11","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("154","11","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("155","11","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("156","11","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("157","11","_weight","");
INSERT INTO `wp_postmeta` VALUES("158","11","_length","");
INSERT INTO `wp_postmeta` VALUES("159","11","_width","");
INSERT INTO `wp_postmeta` VALUES("160","11","_height","");
INSERT INTO `wp_postmeta` VALUES("161","11","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("162","11","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("163","11","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("164","11","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("165","11","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("166","11","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("167","11","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("168","11","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("169","11","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("170","11","_stock","");
INSERT INTO `wp_postmeta` VALUES("171","11","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("172","11","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("173","11","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("174","11","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("175","11","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("176","11","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("177","11","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("178","11","_price","18");
INSERT INTO `wp_postmeta` VALUES("180","12","_sku","woo-belt");
INSERT INTO `wp_postmeta` VALUES("181","12","_regular_price","65");
INSERT INTO `wp_postmeta` VALUES("182","12","_sale_price","55");
INSERT INTO `wp_postmeta` VALUES("183","12","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("184","12","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("185","12","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("186","12","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("187","12","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("188","12","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("189","12","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("190","12","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("191","12","_weight","");
INSERT INTO `wp_postmeta` VALUES("192","12","_length","");
INSERT INTO `wp_postmeta` VALUES("193","12","_width","");
INSERT INTO `wp_postmeta` VALUES("194","12","_height","");
INSERT INTO `wp_postmeta` VALUES("195","12","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("196","12","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("197","12","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("198","12","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("199","12","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("200","12","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("201","12","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("202","12","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("203","12","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("204","12","_stock","");
INSERT INTO `wp_postmeta` VALUES("205","12","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("206","12","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("207","12","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("208","12","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("209","12","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("210","12","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("211","12","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("212","12","_price","55");
INSERT INTO `wp_postmeta` VALUES("214","13","_sku","woo-cap");
INSERT INTO `wp_postmeta` VALUES("215","13","_regular_price","18");
INSERT INTO `wp_postmeta` VALUES("216","13","_sale_price","16");
INSERT INTO `wp_postmeta` VALUES("217","13","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("218","13","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("219","13","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("220","13","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("221","13","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("222","13","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("223","13","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("224","13","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("225","13","_weight","");
INSERT INTO `wp_postmeta` VALUES("226","13","_length","");
INSERT INTO `wp_postmeta` VALUES("227","13","_width","");
INSERT INTO `wp_postmeta` VALUES("228","13","_height","");
INSERT INTO `wp_postmeta` VALUES("229","13","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("230","13","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("231","13","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("232","13","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("233","13","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("234","13","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("235","13","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("236","13","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("237","13","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("238","13","_stock","");
INSERT INTO `wp_postmeta` VALUES("239","13","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("240","13","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("241","13","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("242","13","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("243","13","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("244","13","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("245","13","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("246","13","_price","16");
INSERT INTO `wp_postmeta` VALUES("248","14","_sku","woo-sunglasses");
INSERT INTO `wp_postmeta` VALUES("249","14","_regular_price","90");
INSERT INTO `wp_postmeta` VALUES("250","14","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("251","14","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("252","14","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("253","14","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("254","14","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("255","14","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("256","14","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("257","14","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("258","14","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("259","14","_weight","");
INSERT INTO `wp_postmeta` VALUES("260","14","_length","");
INSERT INTO `wp_postmeta` VALUES("261","14","_width","");
INSERT INTO `wp_postmeta` VALUES("262","14","_height","");
INSERT INTO `wp_postmeta` VALUES("263","14","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("264","14","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("265","14","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("266","14","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("267","14","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("268","14","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("269","14","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("270","14","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("271","14","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("272","14","_stock","");
INSERT INTO `wp_postmeta` VALUES("273","14","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("274","14","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("275","14","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("276","14","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("277","14","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("278","14","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("279","14","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("280","14","_price","90");
INSERT INTO `wp_postmeta` VALUES("282","15","_sku","woo-hoodie-with-pocket");
INSERT INTO `wp_postmeta` VALUES("283","15","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("284","15","_sale_price","35");
INSERT INTO `wp_postmeta` VALUES("285","15","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("286","15","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("287","15","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("288","15","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("289","15","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("290","15","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("291","15","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("292","15","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("293","15","_weight","");
INSERT INTO `wp_postmeta` VALUES("294","15","_length","");
INSERT INTO `wp_postmeta` VALUES("295","15","_width","");
INSERT INTO `wp_postmeta` VALUES("296","15","_height","");
INSERT INTO `wp_postmeta` VALUES("297","15","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("298","15","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("299","15","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("300","15","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("301","15","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("302","15","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("303","15","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("304","15","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("305","15","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("306","15","_stock","");
INSERT INTO `wp_postmeta` VALUES("307","15","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("308","15","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("309","15","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("310","15","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("311","15","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("312","15","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("313","15","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("314","15","_price","35");
INSERT INTO `wp_postmeta` VALUES("316","16","_sku","woo-hoodie-with-zipper");
INSERT INTO `wp_postmeta` VALUES("317","16","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("318","16","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("319","16","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("320","16","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("321","16","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("322","16","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("323","16","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("324","16","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("325","16","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("326","16","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("327","16","_weight","");
INSERT INTO `wp_postmeta` VALUES("328","16","_length","");
INSERT INTO `wp_postmeta` VALUES("329","16","_width","");
INSERT INTO `wp_postmeta` VALUES("330","16","_height","");
INSERT INTO `wp_postmeta` VALUES("331","16","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("332","16","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("333","16","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("334","16","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("335","16","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("336","16","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("337","16","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("338","16","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("339","16","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("340","16","_stock","");
INSERT INTO `wp_postmeta` VALUES("341","16","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("342","16","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("343","16","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("344","16","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("345","16","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("346","16","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("347","16","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("348","16","_price","45");
INSERT INTO `wp_postmeta` VALUES("350","17","_sku","woo-long-sleeve-tee");
INSERT INTO `wp_postmeta` VALUES("351","17","_regular_price","25");
INSERT INTO `wp_postmeta` VALUES("352","17","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("353","17","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("354","17","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("355","17","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("356","17","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("357","17","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("358","17","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("359","17","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("360","17","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("361","17","_weight","");
INSERT INTO `wp_postmeta` VALUES("362","17","_length","");
INSERT INTO `wp_postmeta` VALUES("363","17","_width","");
INSERT INTO `wp_postmeta` VALUES("364","17","_height","");
INSERT INTO `wp_postmeta` VALUES("365","17","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("366","17","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("367","17","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("368","17","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("369","17","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("370","17","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("371","17","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("372","17","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("373","17","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("374","17","_stock","");
INSERT INTO `wp_postmeta` VALUES("375","17","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("376","17","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("377","17","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("378","17","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("379","17","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("380","17","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("381","17","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("382","17","_price","25");
INSERT INTO `wp_postmeta` VALUES("384","18","_sku","woo-polo");
INSERT INTO `wp_postmeta` VALUES("385","18","_regular_price","20");
INSERT INTO `wp_postmeta` VALUES("386","18","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("387","18","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("388","18","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("389","18","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("390","18","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("391","18","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("392","18","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("393","18","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("394","18","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("395","18","_weight","");
INSERT INTO `wp_postmeta` VALUES("396","18","_length","");
INSERT INTO `wp_postmeta` VALUES("397","18","_width","");
INSERT INTO `wp_postmeta` VALUES("398","18","_height","");
INSERT INTO `wp_postmeta` VALUES("399","18","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("400","18","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("401","18","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("402","18","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("403","18","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("404","18","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("405","18","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("406","18","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("407","18","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("408","18","_stock","");
INSERT INTO `wp_postmeta` VALUES("409","18","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("410","18","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("411","18","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("412","18","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("413","18","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("414","18","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("415","18","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("416","18","_price","20");
INSERT INTO `wp_postmeta` VALUES("418","19","_sku","woo-album");
INSERT INTO `wp_postmeta` VALUES("419","19","_regular_price","15");
INSERT INTO `wp_postmeta` VALUES("420","19","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("421","19","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("422","19","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("423","19","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("424","19","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("425","19","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("426","19","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("427","19","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("428","19","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("429","19","_weight","");
INSERT INTO `wp_postmeta` VALUES("430","19","_length","");
INSERT INTO `wp_postmeta` VALUES("431","19","_width","");
INSERT INTO `wp_postmeta` VALUES("432","19","_height","");
INSERT INTO `wp_postmeta` VALUES("433","19","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("434","19","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("435","19","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("436","19","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("437","19","_virtual","yes");
INSERT INTO `wp_postmeta` VALUES("438","19","_downloadable","yes");
INSERT INTO `wp_postmeta` VALUES("439","19","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("440","19","_download_limit","1");
INSERT INTO `wp_postmeta` VALUES("441","19","_download_expiry","1");
INSERT INTO `wp_postmeta` VALUES("442","19","_stock","");
INSERT INTO `wp_postmeta` VALUES("443","19","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("444","19","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("445","19","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("446","19","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("447","19","_downloadable_files","a:2:{s:36:\"2bbb7387-1baa-431d-b07c-c7e1787eb707\";a:3:{s:2:\"id\";s:36:\"2bbb7387-1baa-431d-b07c-c7e1787eb707\";s:4:\"name\";s:8:\"Single 1\";s:4:\"file\";s:85:\"https://demo.woothemes.com/woocommerce/wp-content/uploads/sites/56/2017/08/single.jpg\";}s:36:\"4f8a6c63-6eb1-4663-9a1c-1a2a6de69914\";a:3:{s:2:\"id\";s:36:\"4f8a6c63-6eb1-4663-9a1c-1a2a6de69914\";s:4:\"name\";s:8:\"Single 2\";s:4:\"file\";s:84:\"https://demo.woothemes.com/woocommerce/wp-content/uploads/sites/56/2017/08/album.jpg\";}}");
INSERT INTO `wp_postmeta` VALUES("448","19","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("449","19","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("450","19","_price","15");
INSERT INTO `wp_postmeta` VALUES("452","20","_sku","woo-single");
INSERT INTO `wp_postmeta` VALUES("453","20","_regular_price","3");
INSERT INTO `wp_postmeta` VALUES("454","20","_sale_price","2");
INSERT INTO `wp_postmeta` VALUES("455","20","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("456","20","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("457","20","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("458","20","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("459","20","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("460","20","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("461","20","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("462","20","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("463","20","_weight","");
INSERT INTO `wp_postmeta` VALUES("464","20","_length","");
INSERT INTO `wp_postmeta` VALUES("465","20","_width","");
INSERT INTO `wp_postmeta` VALUES("466","20","_height","");
INSERT INTO `wp_postmeta` VALUES("467","20","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("468","20","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("469","20","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("470","20","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("471","20","_virtual","yes");
INSERT INTO `wp_postmeta` VALUES("472","20","_downloadable","yes");
INSERT INTO `wp_postmeta` VALUES("473","20","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("474","20","_download_limit","1");
INSERT INTO `wp_postmeta` VALUES("475","20","_download_expiry","1");
INSERT INTO `wp_postmeta` VALUES("476","20","_stock","");
INSERT INTO `wp_postmeta` VALUES("477","20","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("478","20","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("479","20","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("480","20","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("481","20","_downloadable_files","a:1:{s:36:\"135d0448-46dc-47e8-ba63-99475300107e\";a:3:{s:2:\"id\";s:36:\"135d0448-46dc-47e8-ba63-99475300107e\";s:4:\"name\";s:6:\"Single\";s:4:\"file\";s:85:\"https://demo.woothemes.com/woocommerce/wp-content/uploads/sites/56/2017/08/single.jpg\";}}");
INSERT INTO `wp_postmeta` VALUES("482","20","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("483","20","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("484","20","_price","2");
INSERT INTO `wp_postmeta` VALUES("486","21","_sku","woo-vneck-tee-red");
INSERT INTO `wp_postmeta` VALUES("487","21","_regular_price","20");
INSERT INTO `wp_postmeta` VALUES("488","21","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("489","21","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("490","21","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("491","21","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("492","21","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("493","21","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("494","21","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("495","21","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("496","21","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("497","21","_weight","");
INSERT INTO `wp_postmeta` VALUES("498","21","_length","");
INSERT INTO `wp_postmeta` VALUES("499","21","_width","");
INSERT INTO `wp_postmeta` VALUES("500","21","_height","");
INSERT INTO `wp_postmeta` VALUES("501","21","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("502","21","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("503","21","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("504","21","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("505","21","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("506","21","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("507","21","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("508","21","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("509","21","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("510","21","_stock","");
INSERT INTO `wp_postmeta` VALUES("511","21","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("512","21","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("513","21","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("514","21","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("515","21","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("516","21","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("517","21","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("518","21","_price","20");
INSERT INTO `wp_postmeta` VALUES("520","22","_sku","woo-vneck-tee-green");
INSERT INTO `wp_postmeta` VALUES("521","22","_regular_price","20");
INSERT INTO `wp_postmeta` VALUES("522","22","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("523","22","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("524","22","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("525","22","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("526","22","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("527","22","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("528","22","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("529","22","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("530","22","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("531","22","_weight","");
INSERT INTO `wp_postmeta` VALUES("532","22","_length","");
INSERT INTO `wp_postmeta` VALUES("533","22","_width","");
INSERT INTO `wp_postmeta` VALUES("534","22","_height","");
INSERT INTO `wp_postmeta` VALUES("535","22","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("536","22","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("537","22","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("538","22","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("539","22","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("540","22","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("541","22","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("542","22","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("543","22","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("544","22","_stock","");
INSERT INTO `wp_postmeta` VALUES("545","22","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("546","22","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("547","22","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("548","22","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("549","22","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("550","22","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("551","22","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("552","22","_price","20");
INSERT INTO `wp_postmeta` VALUES("554","23","_sku","woo-vneck-tee-blue");
INSERT INTO `wp_postmeta` VALUES("555","23","_regular_price","15");
INSERT INTO `wp_postmeta` VALUES("556","23","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("557","23","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("558","23","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("559","23","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("560","23","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("561","23","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("562","23","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("563","23","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("564","23","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("565","23","_weight","");
INSERT INTO `wp_postmeta` VALUES("566","23","_length","");
INSERT INTO `wp_postmeta` VALUES("567","23","_width","");
INSERT INTO `wp_postmeta` VALUES("568","23","_height","");
INSERT INTO `wp_postmeta` VALUES("569","23","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("570","23","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("571","23","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("572","23","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("573","23","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("574","23","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("575","23","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("576","23","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("577","23","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("578","23","_stock","");
INSERT INTO `wp_postmeta` VALUES("579","23","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("580","23","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("581","23","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("582","23","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("583","23","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("584","23","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("585","23","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("586","23","_price","15");
INSERT INTO `wp_postmeta` VALUES("588","24","_sku","woo-hoodie-red");
INSERT INTO `wp_postmeta` VALUES("589","24","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("590","24","_sale_price","42");
INSERT INTO `wp_postmeta` VALUES("591","24","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("592","24","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("593","24","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("594","24","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("595","24","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("596","24","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("597","24","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("598","24","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("599","24","_weight","");
INSERT INTO `wp_postmeta` VALUES("600","24","_length","");
INSERT INTO `wp_postmeta` VALUES("601","24","_width","");
INSERT INTO `wp_postmeta` VALUES("602","24","_height","");
INSERT INTO `wp_postmeta` VALUES("603","24","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("604","24","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("605","24","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("606","24","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("607","24","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("608","24","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("609","24","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("610","24","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("611","24","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("612","24","_stock","");
INSERT INTO `wp_postmeta` VALUES("613","24","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("614","24","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("615","24","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("616","24","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("617","24","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("618","24","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("619","24","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("620","24","_price","42");
INSERT INTO `wp_postmeta` VALUES("622","25","_sku","woo-hoodie-green");
INSERT INTO `wp_postmeta` VALUES("623","25","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("624","25","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("625","25","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("626","25","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("627","25","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("628","25","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("629","25","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("630","25","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("631","25","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("632","25","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("633","25","_weight","");
INSERT INTO `wp_postmeta` VALUES("634","25","_length","");
INSERT INTO `wp_postmeta` VALUES("635","25","_width","");
INSERT INTO `wp_postmeta` VALUES("636","25","_height","");
INSERT INTO `wp_postmeta` VALUES("637","25","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("638","25","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("639","25","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("640","25","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("641","25","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("642","25","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("643","25","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("644","25","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("645","25","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("646","25","_stock","");
INSERT INTO `wp_postmeta` VALUES("647","25","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("648","25","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("649","25","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("650","25","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("651","25","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("652","25","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("653","25","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("654","25","_price","45");
INSERT INTO `wp_postmeta` VALUES("656","26","_sku","woo-hoodie-blue");
INSERT INTO `wp_postmeta` VALUES("657","26","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("658","26","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("659","26","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("660","26","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("661","26","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("662","26","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("663","26","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("664","26","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("665","26","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("666","26","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("667","26","_weight","");
INSERT INTO `wp_postmeta` VALUES("668","26","_length","");
INSERT INTO `wp_postmeta` VALUES("669","26","_width","");
INSERT INTO `wp_postmeta` VALUES("670","26","_height","");
INSERT INTO `wp_postmeta` VALUES("671","26","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("672","26","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("673","26","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("674","26","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("675","26","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("676","26","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("677","26","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("678","26","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("679","26","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("680","26","_stock","");
INSERT INTO `wp_postmeta` VALUES("681","26","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("682","26","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("683","26","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("684","26","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("685","26","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("686","26","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("687","26","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("688","26","_price","45");
INSERT INTO `wp_postmeta` VALUES("690","27","_sku","Woo-tshirt-logo");
INSERT INTO `wp_postmeta` VALUES("691","27","_regular_price","18");
INSERT INTO `wp_postmeta` VALUES("692","27","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("693","27","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("694","27","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("695","27","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("696","27","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("697","27","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("698","27","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("699","27","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("700","27","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("701","27","_weight","");
INSERT INTO `wp_postmeta` VALUES("702","27","_length","");
INSERT INTO `wp_postmeta` VALUES("703","27","_width","");
INSERT INTO `wp_postmeta` VALUES("704","27","_height","");
INSERT INTO `wp_postmeta` VALUES("705","27","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("706","27","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("707","27","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("708","27","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("709","27","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("710","27","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("711","27","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("712","27","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("713","27","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("714","27","_stock","");
INSERT INTO `wp_postmeta` VALUES("715","27","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("716","27","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("717","27","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("718","27","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("719","27","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("720","27","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("721","27","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("722","27","_price","18");
INSERT INTO `wp_postmeta` VALUES("724","28","_sku","Woo-beanie-logo");
INSERT INTO `wp_postmeta` VALUES("725","28","_regular_price","20");
INSERT INTO `wp_postmeta` VALUES("726","28","_sale_price","18");
INSERT INTO `wp_postmeta` VALUES("727","28","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("728","28","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("729","28","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("730","28","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("731","28","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("732","28","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("733","28","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("734","28","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("735","28","_weight","");
INSERT INTO `wp_postmeta` VALUES("736","28","_length","");
INSERT INTO `wp_postmeta` VALUES("737","28","_width","");
INSERT INTO `wp_postmeta` VALUES("738","28","_height","");
INSERT INTO `wp_postmeta` VALUES("739","28","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("740","28","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("741","28","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("742","28","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("743","28","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("744","28","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("745","28","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("746","28","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("747","28","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("748","28","_stock","");
INSERT INTO `wp_postmeta` VALUES("749","28","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("750","28","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("751","28","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("752","28","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("753","28","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("754","28","_product_attributes","a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("755","28","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("756","28","_price","18");
INSERT INTO `wp_postmeta` VALUES("758","29","_sku","logo-collection");
INSERT INTO `wp_postmeta` VALUES("761","29","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("762","29","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("763","29","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("764","29","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("765","29","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("766","29","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("767","29","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("768","29","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("769","29","_weight","");
INSERT INTO `wp_postmeta` VALUES("770","29","_length","");
INSERT INTO `wp_postmeta` VALUES("771","29","_width","");
INSERT INTO `wp_postmeta` VALUES("772","29","_height","");
INSERT INTO `wp_postmeta` VALUES("773","29","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("774","29","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("775","29","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("776","29","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("777","29","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("778","29","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("779","29","_product_image_gallery","51,50,38");
INSERT INTO `wp_postmeta` VALUES("780","29","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("781","29","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("782","29","_stock","");
INSERT INTO `wp_postmeta` VALUES("783","29","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("784","29","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("785","29","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("786","29","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("787","29","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("788","29","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("789","29","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("792","30","_sku","wp-pennant");
INSERT INTO `wp_postmeta` VALUES("793","30","_regular_price","11.05");
INSERT INTO `wp_postmeta` VALUES("794","30","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("795","30","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("796","30","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("797","30","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("798","30","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("799","30","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("800","30","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("801","30","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("802","30","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("803","30","_weight","");
INSERT INTO `wp_postmeta` VALUES("804","30","_length","");
INSERT INTO `wp_postmeta` VALUES("805","30","_width","");
INSERT INTO `wp_postmeta` VALUES("806","30","_height","");
INSERT INTO `wp_postmeta` VALUES("807","30","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("808","30","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("809","30","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("810","30","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("811","30","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("812","30","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("813","30","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("814","30","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("815","30","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("816","30","_stock","");
INSERT INTO `wp_postmeta` VALUES("817","30","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("818","30","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("819","30","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("820","30","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("821","30","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("822","30","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("823","30","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("824","30","_price","11.05");
INSERT INTO `wp_postmeta` VALUES("826","31","_sku","woo-hoodie-blue-logo");
INSERT INTO `wp_postmeta` VALUES("827","31","_regular_price","45");
INSERT INTO `wp_postmeta` VALUES("828","31","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("829","31","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("830","31","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("831","31","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("832","31","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("833","31","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("834","31","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("835","31","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("836","31","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("837","31","_weight","");
INSERT INTO `wp_postmeta` VALUES("838","31","_length","");
INSERT INTO `wp_postmeta` VALUES("839","31","_width","");
INSERT INTO `wp_postmeta` VALUES("840","31","_height","");
INSERT INTO `wp_postmeta` VALUES("841","31","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("842","31","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("843","31","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("844","31","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("845","31","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("846","31","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("847","31","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("848","31","_download_limit","0");
INSERT INTO `wp_postmeta` VALUES("849","31","_download_expiry","0");
INSERT INTO `wp_postmeta` VALUES("850","31","_stock","");
INSERT INTO `wp_postmeta` VALUES("851","31","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("852","31","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("853","31","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("854","31","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("855","31","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("856","31","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("857","31","_product_version","3.4.5");
INSERT INTO `wp_postmeta` VALUES("858","31","_price","45");
INSERT INTO `wp_postmeta` VALUES("860","32","_wp_attached_file","2018/09/vneck-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("861","32","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2018/09/vneck-tee-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("862","32","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vneck-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("863","33","_wp_attached_file","2018/09/vnech-tee-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("864","33","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:29:\"2018/09/vnech-tee-green-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("865","33","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vnech-tee-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("866","34","_wp_attached_file","2018/09/vnech-tee-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("867","34","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2018/09/vnech-tee-blue-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("868","34","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vnech-tee-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("869","7","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("870","7","_wp_old_slug","import-placeholder-for-44");
INSERT INTO `wp_postmeta` VALUES("871","7","_thumbnail_id","32");
INSERT INTO `wp_postmeta` VALUES("872","35","_wp_attached_file","2018/09/hoodie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("873","35","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2018/09/hoodie-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"hoodie-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"hoodie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"hoodie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("874","35","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("875","36","_wp_attached_file","2018/09/hoodie-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("876","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:25:\"2018/09/hoodie-blue-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("877","36","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("878","37","_wp_attached_file","2018/09/hoodie-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("879","37","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:26:\"2018/09/hoodie-green-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("880","37","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("881","38","_wp_attached_file","2018/09/hoodie-with-logo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("882","38","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:30:\"2018/09/hoodie-with-logo-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("883","38","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-logo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("884","8","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("885","8","_wp_old_slug","import-placeholder-for-45");
INSERT INTO `wp_postmeta` VALUES("886","8","_thumbnail_id","35");
INSERT INTO `wp_postmeta` VALUES("887","9","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("888","9","_wp_old_slug","import-placeholder-for-46");
INSERT INTO `wp_postmeta` VALUES("889","9","_thumbnail_id","38");
INSERT INTO `wp_postmeta` VALUES("890","39","_wp_attached_file","2018/09/tshirt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("891","39","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2018/09/tshirt-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"tshirt-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"tshirt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"tshirt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("892","39","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/tshirt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("893","10","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("894","10","_wp_old_slug","import-placeholder-for-47");
INSERT INTO `wp_postmeta` VALUES("895","10","_thumbnail_id","39");
INSERT INTO `wp_postmeta` VALUES("896","40","_wp_attached_file","2018/09/beanie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("897","40","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2018/09/beanie-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"beanie-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"beanie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"beanie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("898","40","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/beanie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("899","11","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("900","11","_wp_old_slug","import-placeholder-for-48");
INSERT INTO `wp_postmeta` VALUES("901","11","_thumbnail_id","40");
INSERT INTO `wp_postmeta` VALUES("902","41","_wp_attached_file","2018/09/belt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("903","41","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:18:\"2018/09/belt-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"belt-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"belt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"belt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("904","41","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/belt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("905","12","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("906","12","_wp_old_slug","import-placeholder-for-58");
INSERT INTO `wp_postmeta` VALUES("907","12","_thumbnail_id","41");
INSERT INTO `wp_postmeta` VALUES("908","42","_wp_attached_file","2018/09/cap-2.jpg");
INSERT INTO `wp_postmeta` VALUES("909","42","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:17:\"2018/09/cap-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"cap-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"cap-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"cap-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("910","42","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/cap-2.jpg");
INSERT INTO `wp_postmeta` VALUES("911","13","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("912","13","_wp_old_slug","import-placeholder-for-60");
INSERT INTO `wp_postmeta` VALUES("913","13","_thumbnail_id","42");
INSERT INTO `wp_postmeta` VALUES("914","43","_wp_attached_file","2018/09/sunglasses-2.jpg");
INSERT INTO `wp_postmeta` VALUES("915","43","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:24:\"2018/09/sunglasses-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("916","43","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/sunglasses-2.jpg");
INSERT INTO `wp_postmeta` VALUES("917","14","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("918","14","_wp_old_slug","import-placeholder-for-62");
INSERT INTO `wp_postmeta` VALUES("919","14","_thumbnail_id","43");
INSERT INTO `wp_postmeta` VALUES("920","44","_wp_attached_file","2018/09/hoodie-with-pocket-2.jpg");
INSERT INTO `wp_postmeta` VALUES("921","44","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:32:\"2018/09/hoodie-with-pocket-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("922","44","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-pocket-2.jpg");
INSERT INTO `wp_postmeta` VALUES("923","15","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("924","15","_wp_old_slug","import-placeholder-for-64");
INSERT INTO `wp_postmeta` VALUES("925","15","_thumbnail_id","44");
INSERT INTO `wp_postmeta` VALUES("926","45","_wp_attached_file","2018/09/hoodie-with-zipper-2.jpg");
INSERT INTO `wp_postmeta` VALUES("927","45","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:32:\"2018/09/hoodie-with-zipper-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("928","45","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-zipper-2.jpg");
INSERT INTO `wp_postmeta` VALUES("929","16","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("930","16","_wp_old_slug","import-placeholder-for-66");
INSERT INTO `wp_postmeta` VALUES("931","16","_thumbnail_id","45");
INSERT INTO `wp_postmeta` VALUES("932","46","_wp_attached_file","2018/09/long-sleeve-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("933","46","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:29:\"2018/09/long-sleeve-tee-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("934","46","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/long-sleeve-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("935","17","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("936","17","_wp_old_slug","import-placeholder-for-68");
INSERT INTO `wp_postmeta` VALUES("937","17","_thumbnail_id","46");
INSERT INTO `wp_postmeta` VALUES("938","47","_wp_attached_file","2018/09/polo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("939","47","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:800;s:4:\"file\";s:18:\"2018/09/polo-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"polo-2-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"polo-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"polo-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("940","47","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/polo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("941","18","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("942","18","_wp_old_slug","import-placeholder-for-70");
INSERT INTO `wp_postmeta` VALUES("943","18","_thumbnail_id","47");
INSERT INTO `wp_postmeta` VALUES("944","48","_wp_attached_file","2018/09/album-1.jpg");
INSERT INTO `wp_postmeta` VALUES("945","48","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:19:\"2018/09/album-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"album-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"album-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"album-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("946","48","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/album-1.jpg");
INSERT INTO `wp_postmeta` VALUES("947","19","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("948","19","_wp_old_slug","import-placeholder-for-73");
INSERT INTO `wp_postmeta` VALUES("949","19","_thumbnail_id","48");
INSERT INTO `wp_postmeta` VALUES("950","49","_wp_attached_file","2018/09/single-1.jpg");
INSERT INTO `wp_postmeta` VALUES("951","49","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:20:\"2018/09/single-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"single-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"single-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"single-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("952","49","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/single-1.jpg");
INSERT INTO `wp_postmeta` VALUES("953","20","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("954","20","_wp_old_slug","import-placeholder-for-75");
INSERT INTO `wp_postmeta` VALUES("955","20","_thumbnail_id","49");
INSERT INTO `wp_postmeta` VALUES("956","21","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("957","21","_wp_old_slug","import-placeholder-for-76");
INSERT INTO `wp_postmeta` VALUES("958","21","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("959","21","_thumbnail_id","32");
INSERT INTO `wp_postmeta` VALUES("960","21","attribute_pa_color","red");
INSERT INTO `wp_postmeta` VALUES("961","21","attribute_pa_size","");
INSERT INTO `wp_postmeta` VALUES("962","22","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("963","22","_wp_old_slug","import-placeholder-for-77");
INSERT INTO `wp_postmeta` VALUES("964","22","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("965","22","_thumbnail_id","33");
INSERT INTO `wp_postmeta` VALUES("966","22","attribute_pa_color","green");
INSERT INTO `wp_postmeta` VALUES("967","22","attribute_pa_size","");
INSERT INTO `wp_postmeta` VALUES("968","23","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("969","23","_wp_old_slug","import-placeholder-for-78");
INSERT INTO `wp_postmeta` VALUES("970","23","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("971","23","_thumbnail_id","34");
INSERT INTO `wp_postmeta` VALUES("972","23","attribute_pa_color","blue");
INSERT INTO `wp_postmeta` VALUES("973","23","attribute_pa_size","");
INSERT INTO `wp_postmeta` VALUES("974","24","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("975","24","_wp_old_slug","import-placeholder-for-79");
INSERT INTO `wp_postmeta` VALUES("976","24","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("977","24","_thumbnail_id","35");
INSERT INTO `wp_postmeta` VALUES("978","24","attribute_pa_color","red");
INSERT INTO `wp_postmeta` VALUES("979","24","attribute_logo","No");
INSERT INTO `wp_postmeta` VALUES("980","25","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("981","25","_wp_old_slug","import-placeholder-for-80");
INSERT INTO `wp_postmeta` VALUES("982","25","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("983","25","_thumbnail_id","37");
INSERT INTO `wp_postmeta` VALUES("984","25","attribute_pa_color","green");
INSERT INTO `wp_postmeta` VALUES("985","25","attribute_logo","No");
INSERT INTO `wp_postmeta` VALUES("986","26","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("987","26","_wp_old_slug","import-placeholder-for-81");
INSERT INTO `wp_postmeta` VALUES("988","26","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("989","26","_thumbnail_id","36");
INSERT INTO `wp_postmeta` VALUES("990","26","attribute_pa_color","blue");
INSERT INTO `wp_postmeta` VALUES("991","26","attribute_logo","No");
INSERT INTO `wp_postmeta` VALUES("992","50","_wp_attached_file","2018/09/t-shirt-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("993","50","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:31:\"2018/09/t-shirt-with-logo-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("994","50","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/t-shirt-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("995","27","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("996","27","_wp_old_slug","import-placeholder-for-83");
INSERT INTO `wp_postmeta` VALUES("997","27","_thumbnail_id","50");
INSERT INTO `wp_postmeta` VALUES("998","7","_price","15");
INSERT INTO `wp_postmeta` VALUES("999","7","_price","20");
INSERT INTO `wp_postmeta` VALUES("1000","7","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("1001","7","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("1006","51","_wp_attached_file","2018/09/beanie-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1007","51","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:30:\"2018/09/beanie-with-logo-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("1008","51","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/beanie-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1009","28","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("1010","28","_wp_old_slug","import-placeholder-for-85");
INSERT INTO `wp_postmeta` VALUES("1011","28","_thumbnail_id","51");
INSERT INTO `wp_postmeta` VALUES("1012","52","_wp_attached_file","2018/09/logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1013","52","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:799;s:4:\"file\";s:18:\"2018/09/logo-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"logo-1-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"logo-1-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"logo-1-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("1014","52","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1015","29","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("1016","29","_wp_old_slug","import-placeholder-for-87");
INSERT INTO `wp_postmeta` VALUES("1017","29","_children","a:3:{i:0;i:9;i:1;i:10;i:2;i:11;}");
INSERT INTO `wp_postmeta` VALUES("1018","29","_thumbnail_id","52");
INSERT INTO `wp_postmeta` VALUES("1019","29","_price","18");
INSERT INTO `wp_postmeta` VALUES("1020","29","_price","45");
INSERT INTO `wp_postmeta` VALUES("1021","53","_wp_attached_file","2018/09/pennant-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1022","53","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:21:\"2018/09/pennant-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"pennant-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"pennant-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"pennant-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("1023","53","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/pennant-1.jpg");
INSERT INTO `wp_postmeta` VALUES("1024","30","_wpcom_is_markdown","1");
INSERT INTO `wp_postmeta` VALUES("1025","30","_wp_old_slug","import-placeholder-for-89");
INSERT INTO `wp_postmeta` VALUES("1026","30","_thumbnail_id","53");
INSERT INTO `wp_postmeta` VALUES("1027","30","_product_url","https://mercantile.wordpress.org/product/wordpress-pennant/");
INSERT INTO `wp_postmeta` VALUES("1028","30","_button_text","Buy on the WordPress swag store!");
INSERT INTO `wp_postmeta` VALUES("1029","31","_wpcom_is_markdown","");
INSERT INTO `wp_postmeta` VALUES("1030","31","_wp_old_slug","import-placeholder-for-90");
INSERT INTO `wp_postmeta` VALUES("1031","31","_variation_description","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.");
INSERT INTO `wp_postmeta` VALUES("1032","31","_thumbnail_id","38");
INSERT INTO `wp_postmeta` VALUES("1033","31","attribute_pa_color","blue");
INSERT INTO `wp_postmeta` VALUES("1034","31","attribute_logo","Yes");
INSERT INTO `wp_postmeta` VALUES("1035","8","_price","42");
INSERT INTO `wp_postmeta` VALUES("1036","8","_price","45");
INSERT INTO `wp_postmeta` VALUES("1037","8","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("1038","8","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("1039","55","_wp_attached_file","2018/09/priroda_gory_nebo_ozero_oblaka_81150_1920x1080.jpg");
INSERT INTO `wp_postmeta` VALUES("1040","55","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:58:\"2018/09/priroda_gory_nebo_ozero_oblaka_81150_1920x1080.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:59:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:58:\"priroda_gory_nebo_ozero_oblaka_81150_1920x1080-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES("1","1","2018-09-03 12:47:18","2018-09-03 09:47:18","Ласкаво просимо до WordPress. Це ваш перший запис. Відредагуйте або видаліть його, потім пишіть!","Привіт, світ!","","publish","open","open","","pryvit-svit","","","2018-09-03 12:47:18","2018-09-03 09:47:18","","0","http://study.woo/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2018-09-03 12:47:18","2018-09-03 09:47:18","Це приклад сторінки. Вона відрізняється від записів блогу, бо залишається на одному місці і відображається в меню сайту (у більшості тем). Більшість людей починають зі сторінки, яка представляє їх потенційним відвідувачам сайту. На ній можна написати щось на кшталт цього:

<blockquote>Привіт! Вдень я кур\'єр, а ввечері - актор що подає надії. А це мій блог. Я живу у Львові, люблю свого чудового собаку Бровка та карпатський чай. (І ще потрапляти під дощ.)</blockquote>

...або цього:

<blockquote>Компанія \"Штучки АБВ\" була заснована в 1992 році, і з тих пір забезпечує людей відмінними штучками. Компанія знаходиться в Стрию, має штат з понад 2000 співробітників і приносить багато користі жителям Стрия.</blockquote>

Як новому користувачу WordPress, вам слід перейти до <a href=\"http://study.woo/wp-admin/\">вашої майстерні</a>, щоб видалити цю сторінку і створити нові сторінки для вашого вмісту. Насолоджуйтесь!","Зразок сторінки","","publish","closed","open","","sample-page","","","2018-09-03 12:47:18","2018-09-03 09:47:18","","0","http://study.woo/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2018-09-03 12:47:18","2018-09-03 09:47:18","<h2>Хто ми</h2><p>Наша адреса сайту: http://study.woo.</p><h2>Які особисті дані ми збираємо та чому ми їх збираємо</h2><h3>Коментарі</h3><p>Коли відвідувачі залишають коментарі на сайті, ми збираємо дані, що відображаються у формі коментарів, а також IP-адреси відвідувачів та рядку агента-браузера користувача, щоб допомогти виявити спам.</p><p>Анонімний рядок, створений за вашою адресою електронної пошти (також називається хеш), може бути наданий службі Gravatar, щоб дізнатись, чи ви його використовуєте. Політика конфіденційності служби Gravatar доступна тут: https://automattic.com/privacy/. Після схвалення вашого коментаря, ваше зображення профілю буде видно для громадськості в контексті вашого коментарю.</p><h3>Медіафайли</h3><p>Якщо ви завантажуєте зображення на сайт, вам слід уникати завантаження зображень із вбудованими даними про місцезнаходження (EXIF GPS). Відвідувачі сайту можуть завантажувати та витягувати будь-які дані про місцезнаходження із зображень на сайті.</p><h3>Контактні форми</h3><h3>Cookies</h3><p>Якщо ви залишаєте коментар на нашому сайті, ви можете ввімкнути збереження свого імені, електронної адреси та сайту в файлах cookie. Це для вашої зручності, так що вам не потрібно буде повторно заповнювати ваші дані, коли ви залишатимете наступний коментар. Ці файли cookie зберігатимуться 1 рік.</p><p>Якщо у вас є обліковий запис і ви ввійшли на цей сайт, ми встановимо тимчасовий файл cookie, щоб визначити, чи браузер приймає файли cookie. Цей файл cookie не містить особистих даних і видаляється при закритті веб-переглядача.</p><p>Коли ви ввійдете в систему, ми також встановимо декілька файлів cookie, щоб зберегти інформацію про ваш логін та налаштування екрана. Cookie-файли для входу зберігаються 2 дні, а файли cookie-файлів налаштувань екрану - 1 рік. Якщо ви виберете &quot;Запам\'ятати мене&quot;, ваш логін буде зберігатися протягом 2 тижнів. Якщо ви вийдете зі свого облікового запису, файли cookie логіну будуть видалені.</p><p>Якщо ви редагуєте або публікуєте статтю, у вашому веб-переглядачі буде збережений додатковий файл cookie. Цей файл cookie не містить особистих даних і просто вказує ідентифікатор статті, яку ви щойно редагували. Його термін дії закінчується через 1 день.</p><h3>Вбудований вміст з інших веб-сайтів</h3><p>Статті на цьому сайті можуть містити вбудований вміст (наприклад: відео, зображення, статті тощо). Вбудований вміст з інших сайтів веде себе так само, як би користувач відвідав інший сайт.</p><p>Ці сайти можуть збирати дані про вас, використовувати файли cookie, вбудовані додатки відстеження третіх сторін та стежити за вашою взаємодією з цим вбудованим вмістом. Зокрема відстежувати взаємодію з вбудованим вмістом, якщо у вас є обліковий запис і ви увійшли на цей сайт.</p><h3>Аналітика</h3><h2>З ким ми ділимося вашими даними</h2><h2>Як довго ми зберігаємо ваші дані</h2><p>Якщо ви залишаєте коментар, він та його метадані зберігаються протягом невизначеного терміну. Таким чином, ми можемо автоматично визначати та затверджувати кожен наступний коментар замість того, щоб тримати їх у черзі на модерації.</p><p>Для користувачів, які реєструються на нашому сайті (якщо такі є), ми зберігаємо надану ними персональну інформацію у їхньому профілі користувача. Всі користувачі можуть переглядати, редагувати або видаляти свої особисті дані в будь-який час (за винятком того, що вони не можуть змінити своє ім\'я користувача). Адміністратори сайту також можуть переглядати та редагувати цю інформацію.</p><h2>Які права ви маєте відносно своїх даних</h2><p>Якщо у вас є обліковий запис на цьому сайті або ви залишили коментарі, ви можете подати запит на отримання експортованого файлу особистих даних які ми зберігаємо про вас, включаючи всі дані, які ви надали нам. Ви також можете вимагати, щоб ми стерли будь-які особисті дані, які ми маємо щодо вас. Це не включає будь-які дані, які ми зобов\'язані зберігати в адміністративних, правових та цілях безпеки.</p><h2>Куди ми відправляємо ваші данні</h2><p>Коментарі відвідувачів можуть бути перевірені за допомогою служби автоматичного виявлення спаму.</p><h2>Ваша контактна інформація</h2><h2>Додаткова інформація</h2><h3>Як ми захищаємо ваші данні</h3><h3>Які процедури проти втрати даних ми використовуємо</h3><h3>Від яких третіх сторін ми отримуємо дані</h3><h3>Яке автоматичне рішення приймається  і/або профілювання ми робимо з користувацькими даними</h3><h3>Вимоги до розкриття галузевих нормативних вимог</h3>","Політика конфіденційності","","draft","closed","open","","privacy-policy","","","2018-09-03 12:47:18","2018-09-03 09:47:18","","0","http://study.woo/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("7","1","2018-09-17 11:22:10","2018-09-17 08:22:10","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","V-Neck T-Shirt","This is a variable product.","publish","open","closed","","v-neck-t-shirt","","","2018-09-17 11:22:55","2018-09-17 08:22:55","","0","http://study.woo/product/import-placeholder-for-44/","0","product","","0");
INSERT INTO `wp_posts` VALUES("8","1","2018-09-17 11:22:10","2018-09-17 08:22:10","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Hoodie","This is a variable product.","publish","open","closed","","hoodie","","","2018-09-17 11:23:03","2018-09-17 08:23:03","","0","http://study.woo/product/import-placeholder-for-45/","0","product","","0");
INSERT INTO `wp_posts` VALUES("9","1","2018-09-17 11:22:10","2018-09-17 08:22:10","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Hoodie with Logo","This is a simple product.","publish","open","closed","","hoodie-with-logo","","","2018-09-17 11:22:29","2018-09-17 08:22:29","","0","http://study.woo/product/import-placeholder-for-46/","0","product","","0");
INSERT INTO `wp_posts` VALUES("10","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","T-Shirt","This is a simple product.","publish","open","closed","","t-shirt","","","2018-09-17 11:22:31","2018-09-17 08:22:31","","0","http://study.woo/product/import-placeholder-for-47/","0","product","","0");
INSERT INTO `wp_posts` VALUES("11","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Beanie","This is a simple product.","publish","open","closed","","beanie","","","2018-09-17 11:22:33","2018-09-17 08:22:33","","0","http://study.woo/product/import-placeholder-for-48/","0","product","","0");
INSERT INTO `wp_posts` VALUES("12","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Belt","This is a simple product.","publish","open","closed","","belt","","","2018-09-17 11:22:36","2018-09-17 08:22:36","","0","http://study.woo/product/import-placeholder-for-58/","0","product","","0");
INSERT INTO `wp_posts` VALUES("13","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Cap","This is a simple product.","publish","open","closed","","cap","","","2018-09-17 11:22:38","2018-09-17 08:22:38","","0","http://study.woo/product/import-placeholder-for-60/","0","product","","0");
INSERT INTO `wp_posts` VALUES("14","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Sunglasses","This is a simple product.","publish","open","closed","","sunglasses","","","2018-09-17 11:22:40","2018-09-17 08:22:40","","0","http://study.woo/product/import-placeholder-for-62/","0","product","","0");
INSERT INTO `wp_posts` VALUES("15","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Hoodie with Pocket","This is a simple product.","publish","open","closed","","hoodie-with-pocket","","","2018-09-17 11:22:42","2018-09-17 08:22:42","","0","http://study.woo/product/import-placeholder-for-64/","0","product","","0");
INSERT INTO `wp_posts` VALUES("16","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Hoodie with Zipper","This is a simple product.","publish","open","closed","","hoodie-with-zipper","","","2018-09-17 11:22:44","2018-09-17 08:22:44","","0","http://study.woo/product/import-placeholder-for-66/","0","product","","0");
INSERT INTO `wp_posts` VALUES("17","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Long Sleeve Tee","This is a simple product.","publish","open","closed","","long-sleeve-tee","","","2018-09-17 11:22:46","2018-09-17 08:22:46","","0","http://study.woo/product/import-placeholder-for-68/","0","product","","0");
INSERT INTO `wp_posts` VALUES("18","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Polo","This is a simple product.","publish","open","closed","","polo","","","2018-09-17 11:22:48","2018-09-17 08:22:48","","0","http://study.woo/product/import-placeholder-for-70/","0","product","","0");
INSERT INTO `wp_posts` VALUES("19","1","2018-09-17 11:22:11","2018-09-17 08:22:11","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.","Album","This is a simple, virtual product.","publish","open","closed","","album","","","2018-09-17 11:22:50","2018-09-17 08:22:50","","0","http://study.woo/product/import-placeholder-for-73/","0","product","","0");
INSERT INTO `wp_posts` VALUES("20","1","2018-09-17 11:22:12","2018-09-17 08:22:12","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.","Single","This is a simple, virtual product.","publish","open","closed","","single","","","2018-09-17 11:22:52","2018-09-17 08:22:52","","0","http://study.woo/product/import-placeholder-for-75/","0","product","","0");
INSERT INTO `wp_posts` VALUES("21","1","2018-09-17 11:22:12","2018-09-17 08:22:12","","V-Neck T-Shirt - Red","","publish","closed","closed","","v-neck-t-shirt-red","","","2018-09-17 11:22:52","2018-09-17 08:22:52","","7","http://study.woo/product/import-placeholder-for-76/","0","product_variation","","0");
INSERT INTO `wp_posts` VALUES("22","1","2018-09-17 11:22:12","2018-09-17 08:22:12","","V-Neck T-Shirt - Green","","publish","closed","closed","","v-neck-t-shirt-green","","","2018-09-17 11:22:52","2018-09-17 08:22:52","","7","http://study.woo/product/import-placeholder-for-77/","0","product_variation","","0");
INSERT INTO `wp_posts` VALUES("23","1","2018-09-17 11:22:12","2018-09-17 08:22:12","","V-Neck T-Shirt - Blue","","publish","closed","closed","","v-neck-t-shirt-blue","","","2018-09-17 11:22:52","2018-09-17 08:22:52","","7","http://study.woo/product/import-placeholder-for-78/","0","product_variation","","0");
INSERT INTO `wp_posts` VALUES("24","1","2018-09-17 11:22:12","2018-09-17 08:22:12","","Hoodie - Red, No","","publish","closed","closed","","hoodie-red-no","","","2018-09-17 11:22:53","2018-09-17 08:22:53","","8","http://study.woo/product/import-placeholder-for-79/","1","product_variation","","0");
INSERT INTO `wp_posts` VALUES("25","1","2018-09-17 11:22:12","2018-09-17 08:22:12","","Hoodie - Green, No","","publish","closed","closed","","hoodie-green-no","","","2018-09-17 11:22:53","2018-09-17 08:22:53","","8","http://study.woo/product/import-placeholder-for-80/","2","product_variation","","0");
INSERT INTO `wp_posts` VALUES("26","1","2018-09-17 11:22:12","2018-09-17 08:22:12","","Hoodie - Blue, No","","publish","closed","closed","","hoodie-blue-no","","","2018-09-17 11:22:53","2018-09-17 08:22:53","","8","http://study.woo/product/import-placeholder-for-81/","3","product_variation","","0");
INSERT INTO `wp_posts` VALUES("27","1","2018-09-17 11:22:12","2018-09-17 08:22:12","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","T-Shirt with Logo","This is a simple product.","publish","open","closed","","t-shirt-with-logo","","","2018-09-17 11:22:55","2018-09-17 08:22:55","","0","http://study.woo/product/import-placeholder-for-83/","0","product","","0");
INSERT INTO `wp_posts` VALUES("28","1","2018-09-17 11:22:12","2018-09-17 08:22:12","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Beanie with Logo","This is a simple product.","publish","open","closed","","beanie-with-logo","","","2018-09-17 11:22:58","2018-09-17 08:22:58","","0","http://study.woo/product/import-placeholder-for-85/","0","product","","0");
INSERT INTO `wp_posts` VALUES("29","1","2018-09-17 11:22:12","2018-09-17 08:22:12","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","Logo Collection","This is a grouped product.","publish","open","closed","","logo-collection","","","2018-09-17 11:23:01","2018-09-17 08:23:01","","0","http://study.woo/product/import-placeholder-for-87/","0","product","","0");
INSERT INTO `wp_posts` VALUES("30","1","2018-09-17 11:22:13","2018-09-17 08:22:13","Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.","WordPress Pennant","This is an external product.","publish","open","closed","","wordpress-pennant","","","2018-09-17 11:23:03","2018-09-17 08:23:03","","0","http://study.woo/product/import-placeholder-for-89/","0","product","","0");
INSERT INTO `wp_posts` VALUES("31","1","2018-09-17 11:22:13","2018-09-17 08:22:13","","Hoodie - Blue, Yes","","publish","closed","closed","","hoodie-blue-yes","","","2018-09-17 11:23:03","2018-09-17 08:23:03","","8","http://study.woo/product/import-placeholder-for-90/","0","product_variation","","0");
INSERT INTO `wp_posts` VALUES("32","1","2018-09-17 11:22:15","2018-09-17 08:22:15","","vneck-tee-2.jpg","","inherit","open","closed","","vneck-tee-2-jpg","","","2018-09-17 11:22:15","2018-09-17 08:22:15","","7","http://study.woo/wp-content/uploads/2018/09/vneck-tee-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("33","1","2018-09-17 11:22:16","2018-09-17 08:22:16","","vnech-tee-green-1.jpg","","inherit","open","closed","","vnech-tee-green-1-jpg","","","2018-09-17 11:22:16","2018-09-17 08:22:16","","7","http://study.woo/wp-content/uploads/2018/09/vnech-tee-green-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("34","1","2018-09-17 11:22:19","2018-09-17 08:22:19","","vnech-tee-blue-1.jpg","","inherit","open","closed","","vnech-tee-blue-1-jpg","","","2018-09-17 11:22:19","2018-09-17 08:22:19","","7","http://study.woo/wp-content/uploads/2018/09/vnech-tee-blue-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("35","1","2018-09-17 11:22:21","2018-09-17 08:22:21","","hoodie-2.jpg","","inherit","open","closed","","hoodie-2-jpg","","","2018-09-17 11:22:21","2018-09-17 08:22:21","","8","http://study.woo/wp-content/uploads/2018/09/hoodie-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("36","1","2018-09-17 11:22:24","2018-09-17 08:22:24","","hoodie-blue-1.jpg","","inherit","open","closed","","hoodie-blue-1-jpg","","","2018-09-17 11:22:24","2018-09-17 08:22:24","","8","http://study.woo/wp-content/uploads/2018/09/hoodie-blue-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("37","1","2018-09-17 11:22:26","2018-09-17 08:22:26","","hoodie-green-1.jpg","","inherit","open","closed","","hoodie-green-1-jpg","","","2018-09-17 11:22:26","2018-09-17 08:22:26","","8","http://study.woo/wp-content/uploads/2018/09/hoodie-green-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("38","1","2018-09-17 11:22:28","2018-09-17 08:22:28","","hoodie-with-logo-2.jpg","","inherit","open","closed","","hoodie-with-logo-2-jpg","","","2018-09-17 11:22:28","2018-09-17 08:22:28","","8","http://study.woo/wp-content/uploads/2018/09/hoodie-with-logo-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("39","1","2018-09-17 11:22:30","2018-09-17 08:22:30","","tshirt-2.jpg","","inherit","open","closed","","tshirt-2-jpg","","","2018-09-17 11:22:30","2018-09-17 08:22:30","","10","http://study.woo/wp-content/uploads/2018/09/tshirt-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("40","1","2018-09-17 11:22:32","2018-09-17 08:22:32","","beanie-2.jpg","","inherit","open","closed","","beanie-2-jpg","","","2018-09-17 11:22:32","2018-09-17 08:22:32","","11","http://study.woo/wp-content/uploads/2018/09/beanie-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("41","1","2018-09-17 11:22:35","2018-09-17 08:22:35","","belt-2.jpg","","inherit","open","closed","","belt-2-jpg","","","2018-09-17 11:22:35","2018-09-17 08:22:35","","12","http://study.woo/wp-content/uploads/2018/09/belt-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("42","1","2018-09-17 11:22:37","2018-09-17 08:22:37","","cap-2.jpg","","inherit","open","closed","","cap-2-jpg","","","2018-09-17 11:22:37","2018-09-17 08:22:37","","13","http://study.woo/wp-content/uploads/2018/09/cap-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("43","1","2018-09-17 11:22:39","2018-09-17 08:22:39","","sunglasses-2.jpg","","inherit","open","closed","","sunglasses-2-jpg","","","2018-09-17 11:22:39","2018-09-17 08:22:39","","14","http://study.woo/wp-content/uploads/2018/09/sunglasses-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("44","1","2018-09-17 11:22:41","2018-09-17 08:22:41","","hoodie-with-pocket-2.jpg","","inherit","open","closed","","hoodie-with-pocket-2-jpg","","","2018-09-17 11:22:41","2018-09-17 08:22:41","","15","http://study.woo/wp-content/uploads/2018/09/hoodie-with-pocket-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("45","1","2018-09-17 11:22:44","2018-09-17 08:22:44","","hoodie-with-zipper-2.jpg","","inherit","open","closed","","hoodie-with-zipper-2-jpg","","","2018-09-17 11:22:44","2018-09-17 08:22:44","","16","http://study.woo/wp-content/uploads/2018/09/hoodie-with-zipper-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("46","1","2018-09-17 11:22:46","2018-09-17 08:22:46","","long-sleeve-tee-2.jpg","","inherit","open","closed","","long-sleeve-tee-2-jpg","","","2018-09-17 11:22:46","2018-09-17 08:22:46","","17","http://study.woo/wp-content/uploads/2018/09/long-sleeve-tee-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("47","1","2018-09-17 11:22:47","2018-09-17 08:22:47","","polo-2.jpg","","inherit","open","closed","","polo-2-jpg","","","2018-09-17 11:22:47","2018-09-17 08:22:47","","18","http://study.woo/wp-content/uploads/2018/09/polo-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("48","1","2018-09-17 11:22:50","2018-09-17 08:22:50","","album-1.jpg","","inherit","open","closed","","album-1-jpg","","","2018-09-17 11:22:50","2018-09-17 08:22:50","","19","http://study.woo/wp-content/uploads/2018/09/album-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("49","1","2018-09-17 11:22:52","2018-09-17 08:22:52","","single-1.jpg","","inherit","open","closed","","single-1-jpg","","","2018-09-17 11:22:52","2018-09-17 08:22:52","","20","http://study.woo/wp-content/uploads/2018/09/single-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("50","1","2018-09-17 11:22:54","2018-09-17 08:22:54","","t-shirt-with-logo-1.jpg","","inherit","open","closed","","t-shirt-with-logo-1-jpg","","","2018-09-17 11:22:54","2018-09-17 08:22:54","","27","http://study.woo/wp-content/uploads/2018/09/t-shirt-with-logo-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("51","1","2018-09-17 11:22:58","2018-09-17 08:22:58","","beanie-with-logo-1.jpg","","inherit","open","closed","","beanie-with-logo-1-jpg","","","2018-09-17 11:22:58","2018-09-17 08:22:58","","28","http://study.woo/wp-content/uploads/2018/09/beanie-with-logo-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("52","1","2018-09-17 11:23:00","2018-09-17 08:23:00","","logo-1.jpg","","inherit","open","closed","","logo-1-jpg","","","2018-09-17 11:23:00","2018-09-17 08:23:00","","29","http://study.woo/wp-content/uploads/2018/09/logo-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("53","1","2018-09-17 11:23:03","2018-09-17 08:23:03","","pennant-1.jpg","","inherit","open","closed","","pennant-1-jpg","","","2018-09-17 11:23:03","2018-09-17 08:23:03","","30","http://study.woo/wp-content/uploads/2018/09/pennant-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("55","1","2018-09-18 13:48:11","2018-09-18 10:48:11","","priroda_gory_nebo_ozero_oblaka_81150_1920x1080","","inherit","open","closed","","priroda_gory_nebo_ozero_oblaka_81150_1920x1080","","","2018-09-18 13:48:11","2018-09-18 10:48:11","","0","http://study.woo/wp-content/uploads/2018/09/priroda_gory_nebo_ozero_oblaka_81150_1920x1080.jpg","0","attachment","image/jpeg","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("7","4","0");
INSERT INTO `wp_term_relationships` VALUES("7","8","0");
INSERT INTO `wp_term_relationships` VALUES("7","17","0");
INSERT INTO `wp_term_relationships` VALUES("7","22","0");
INSERT INTO `wp_term_relationships` VALUES("7","23","0");
INSERT INTO `wp_term_relationships` VALUES("7","24","0");
INSERT INTO `wp_term_relationships` VALUES("7","25","0");
INSERT INTO `wp_term_relationships` VALUES("7","26","0");
INSERT INTO `wp_term_relationships` VALUES("7","27","0");
INSERT INTO `wp_term_relationships` VALUES("8","4","0");
INSERT INTO `wp_term_relationships` VALUES("8","18","0");
INSERT INTO `wp_term_relationships` VALUES("8","22","0");
INSERT INTO `wp_term_relationships` VALUES("8","23","0");
INSERT INTO `wp_term_relationships` VALUES("8","24","0");
INSERT INTO `wp_term_relationships` VALUES("9","2","0");
INSERT INTO `wp_term_relationships` VALUES("9","18","0");
INSERT INTO `wp_term_relationships` VALUES("9","22","0");
INSERT INTO `wp_term_relationships` VALUES("10","2","0");
INSERT INTO `wp_term_relationships` VALUES("10","17","0");
INSERT INTO `wp_term_relationships` VALUES("10","28","0");
INSERT INTO `wp_term_relationships` VALUES("11","2","0");
INSERT INTO `wp_term_relationships` VALUES("11","19","0");
INSERT INTO `wp_term_relationships` VALUES("11","24","0");
INSERT INTO `wp_term_relationships` VALUES("12","2","0");
INSERT INTO `wp_term_relationships` VALUES("12","19","0");
INSERT INTO `wp_term_relationships` VALUES("13","2","0");
INSERT INTO `wp_term_relationships` VALUES("13","8","0");
INSERT INTO `wp_term_relationships` VALUES("13","19","0");
INSERT INTO `wp_term_relationships` VALUES("13","29","0");
INSERT INTO `wp_term_relationships` VALUES("14","2","0");
INSERT INTO `wp_term_relationships` VALUES("14","8","0");
INSERT INTO `wp_term_relationships` VALUES("14","19","0");
INSERT INTO `wp_term_relationships` VALUES("15","2","0");
INSERT INTO `wp_term_relationships` VALUES("15","6","0");
INSERT INTO `wp_term_relationships` VALUES("15","7","0");
INSERT INTO `wp_term_relationships` VALUES("15","8","0");
INSERT INTO `wp_term_relationships` VALUES("15","18","0");
INSERT INTO `wp_term_relationships` VALUES("15","28","0");
INSERT INTO `wp_term_relationships` VALUES("16","2","0");
INSERT INTO `wp_term_relationships` VALUES("16","8","0");
INSERT INTO `wp_term_relationships` VALUES("16","18","0");
INSERT INTO `wp_term_relationships` VALUES("17","2","0");
INSERT INTO `wp_term_relationships` VALUES("17","17","0");
INSERT INTO `wp_term_relationships` VALUES("17","23","0");
INSERT INTO `wp_term_relationships` VALUES("18","2","0");
INSERT INTO `wp_term_relationships` VALUES("18","17","0");
INSERT INTO `wp_term_relationships` VALUES("18","22","0");
INSERT INTO `wp_term_relationships` VALUES("19","2","0");
INSERT INTO `wp_term_relationships` VALUES("19","20","0");
INSERT INTO `wp_term_relationships` VALUES("20","2","0");
INSERT INTO `wp_term_relationships` VALUES("20","20","0");
INSERT INTO `wp_term_relationships` VALUES("21","15","0");
INSERT INTO `wp_term_relationships` VALUES("22","15","0");
INSERT INTO `wp_term_relationships` VALUES("23","15","0");
INSERT INTO `wp_term_relationships` VALUES("24","15","0");
INSERT INTO `wp_term_relationships` VALUES("25","15","0");
INSERT INTO `wp_term_relationships` VALUES("26","15","0");
INSERT INTO `wp_term_relationships` VALUES("27","2","0");
INSERT INTO `wp_term_relationships` VALUES("27","17","0");
INSERT INTO `wp_term_relationships` VALUES("27","28","0");
INSERT INTO `wp_term_relationships` VALUES("28","2","0");
INSERT INTO `wp_term_relationships` VALUES("28","19","0");
INSERT INTO `wp_term_relationships` VALUES("28","24","0");
INSERT INTO `wp_term_relationships` VALUES("29","3","0");
INSERT INTO `wp_term_relationships` VALUES("29","16","0");
INSERT INTO `wp_term_relationships` VALUES("30","5","0");
INSERT INTO `wp_term_relationships` VALUES("30","21","0");
INSERT INTO `wp_term_relationships` VALUES("31","15","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","product_type","","0","14");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","product_type","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","product_type","","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","product_type","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","product_visibility","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","product_visibility","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","product_visibility","","0","5");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("11","11","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("12","12","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("13","13","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("14","14","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("15","15","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("16","16","product_cat","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("17","17","product_cat","","16","5");
INSERT INTO `wp_term_taxonomy` VALUES("18","18","product_cat","","16","4");
INSERT INTO `wp_term_taxonomy` VALUES("19","19","product_cat","","16","5");
INSERT INTO `wp_term_taxonomy` VALUES("20","20","product_cat","","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("21","21","product_cat","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("22","22","pa_color","","0","4");
INSERT INTO `wp_term_taxonomy` VALUES("23","23","pa_color","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("24","24","pa_color","","0","4");
INSERT INTO `wp_term_taxonomy` VALUES("25","25","pa_size","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("26","26","pa_size","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("27","27","pa_size","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("28","28","pa_color","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("29","29","pa_color","","0","1");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_termmeta` VALUES("1","15","product_count_product_cat","0");
INSERT INTO `wp_termmeta` VALUES("2","16","order","0");
INSERT INTO `wp_termmeta` VALUES("3","17","order","0");
INSERT INTO `wp_termmeta` VALUES("4","18","order","0");
INSERT INTO `wp_termmeta` VALUES("5","19","order","0");
INSERT INTO `wp_termmeta` VALUES("6","20","order","0");
INSERT INTO `wp_termmeta` VALUES("7","21","order","0");
INSERT INTO `wp_termmeta` VALUES("8","17","product_count_product_cat","5");
INSERT INTO `wp_termmeta` VALUES("9","16","product_count_product_cat","14");
INSERT INTO `wp_termmeta` VALUES("10","22","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("11","23","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("12","24","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("13","25","order_pa_size","0");
INSERT INTO `wp_termmeta` VALUES("14","26","order_pa_size","0");
INSERT INTO `wp_termmeta` VALUES("15","27","order_pa_size","0");
INSERT INTO `wp_termmeta` VALUES("16","18","product_count_product_cat","3");
INSERT INTO `wp_termmeta` VALUES("17","28","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("18","19","product_count_product_cat","5");
INSERT INTO `wp_termmeta` VALUES("19","29","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("20","20","product_count_product_cat","2");
INSERT INTO `wp_termmeta` VALUES("21","21","product_count_product_cat","1");


DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES("1","Без категорії","bez-kategoriyi","0");
INSERT INTO `wp_terms` VALUES("2","simple","simple","0");
INSERT INTO `wp_terms` VALUES("3","grouped","grouped","0");
INSERT INTO `wp_terms` VALUES("4","variable","variable","0");
INSERT INTO `wp_terms` VALUES("5","external","external","0");
INSERT INTO `wp_terms` VALUES("6","exclude-from-search","exclude-from-search","0");
INSERT INTO `wp_terms` VALUES("7","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `wp_terms` VALUES("8","featured","featured","0");
INSERT INTO `wp_terms` VALUES("9","outofstock","outofstock","0");
INSERT INTO `wp_terms` VALUES("10","rated-1","rated-1","0");
INSERT INTO `wp_terms` VALUES("11","rated-2","rated-2","0");
INSERT INTO `wp_terms` VALUES("12","rated-3","rated-3","0");
INSERT INTO `wp_terms` VALUES("13","rated-4","rated-4","0");
INSERT INTO `wp_terms` VALUES("14","rated-5","rated-5","0");
INSERT INTO `wp_terms` VALUES("15","Uncategorized","uncategorized","0");
INSERT INTO `wp_terms` VALUES("16","Clothing","clothing","0");
INSERT INTO `wp_terms` VALUES("17","Tshirts","tshirts","0");
INSERT INTO `wp_terms` VALUES("18","Hoodies","hoodies","0");
INSERT INTO `wp_terms` VALUES("19","Accessories","accessories","0");
INSERT INTO `wp_terms` VALUES("20","Music","music","0");
INSERT INTO `wp_terms` VALUES("21","Decor","decor","0");
INSERT INTO `wp_terms` VALUES("22","Blue","blue","0");
INSERT INTO `wp_terms` VALUES("23","Green","green","0");
INSERT INTO `wp_terms` VALUES("24","Red","red","0");
INSERT INTO `wp_terms` VALUES("25","Large","large","0");
INSERT INTO `wp_terms` VALUES("26","Medium","medium","0");
INSERT INTO `wp_terms` VALUES("27","Small","small","0");
INSERT INTO `wp_terms` VALUES("28","Gray","gray","0");
INSERT INTO `wp_terms` VALUES("29","Yellow","yellow","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","wp496_privacy");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"5f8d0bc2b7f63cd237ae71ede9ebef73937481e534d9aef92c4c2f825c7b276b\";a:4:{s:10:\"expiration\";i:1538035865;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:108:\"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36\";s:5:\"login\";i:1537863065;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","54");
INSERT INTO `wp_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","wp_user-settings","hidetb=0&libraryContent=browse");
INSERT INTO `wp_usermeta` VALUES("20","1","wp_user-settings-time","1537267690");
INSERT INTO `wp_usermeta` VALUES("22","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}");
INSERT INTO `wp_usermeta` VALUES("23","1","_yoast_wpseo_profile_updated","1535980315");
INSERT INTO `wp_usermeta` VALUES("24","1","wc_last_active","1537833600");
INSERT INTO `wp_usermeta` VALUES("29","1","wp_woocommerce_product_import_mapping","a:51:{i:0;s:2:\"id\";i:1;s:4:\"type\";i:2;s:3:\"sku\";i:3;s:4:\"name\";i:4;s:9:\"published\";i:5;s:8:\"featured\";i:6;s:18:\"catalog_visibility\";i:7;s:17:\"short_description\";i:8;s:11:\"description\";i:9;s:17:\"date_on_sale_from\";i:10;s:15:\"date_on_sale_to\";i:11;s:10:\"tax_status\";i:12;s:9:\"tax_class\";i:13;s:12:\"stock_status\";i:14;s:14:\"stock_quantity\";i:15;s:10:\"backorders\";i:16;s:17:\"sold_individually\";i:17;s:0:\"\";i:18;s:0:\"\";i:19;s:0:\"\";i:20;s:0:\"\";i:21;s:15:\"reviews_allowed\";i:22;s:13:\"purchase_note\";i:23;s:10:\"sale_price\";i:24;s:13:\"regular_price\";i:25;s:12:\"category_ids\";i:26;s:7:\"tag_ids\";i:27;s:17:\"shipping_class_id\";i:28;s:6:\"images\";i:29;s:14:\"download_limit\";i:30;s:15:\"download_expiry\";i:31;s:9:\"parent_id\";i:32;s:16:\"grouped_products\";i:33;s:10:\"upsell_ids\";i:34;s:14:\"cross_sell_ids\";i:35;s:11:\"product_url\";i:36;s:11:\"button_text\";i:37;s:10:\"menu_order\";i:38;s:16:\"attributes:name1\";i:39;s:17:\"attributes:value1\";i:40;s:19:\"attributes:visible1\";i:41;s:20:\"attributes:taxonomy1\";i:42;s:16:\"attributes:name2\";i:43;s:17:\"attributes:value2\";i:44;s:19:\"attributes:visible2\";i:45;s:20:\"attributes:taxonomy2\";i:46;s:23:\"meta:_wpcom_is_markdown\";i:47;s:15:\"downloads:name1\";i:48;s:14:\"downloads:url1\";i:49;s:15:\"downloads:name2\";i:50;s:14:\"downloads:url2\";}");
INSERT INTO `wp_usermeta` VALUES("30","1","wp_product_import_error_log","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("31","1","last_login_time","2018-09-25 11:11:05");
INSERT INTO `wp_usermeta` VALUES("32","2","nickname","andyblacknredd");
INSERT INTO `wp_usermeta` VALUES("33","2","first_name","");
INSERT INTO `wp_usermeta` VALUES("34","2","last_name","");
INSERT INTO `wp_usermeta` VALUES("35","2","description","");
INSERT INTO `wp_usermeta` VALUES("36","2","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("37","2","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("38","2","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("39","2","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("40","2","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("41","2","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("42","2","locale","");
INSERT INTO `wp_usermeta` VALUES("43","2","wp_capabilities","a:1:{s:8:\"customer\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("44","2","wp_user_level","0");
INSERT INTO `wp_usermeta` VALUES("45","2","_yoast_wpseo_profile_updated","1537260378");
INSERT INTO `wp_usermeta` VALUES("46","2","session_tokens","a:1:{s:64:\"9fbb36c740e64f2e0b652edec2be9dd5e41c5799eac1fafdfdb69da150677a07\";a:4:{s:10:\"expiration\";i:1538469979;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:108:\"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36\";s:5:\"login\";i:1537260379;}}");
INSERT INTO `wp_usermeta` VALUES("48","2","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}");
INSERT INTO `wp_usermeta` VALUES("49","2","wc_last_active","1537228800");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$BriNN0FNrDJHLWnkocCSKpNG273PrX/","admin","andyblacknred@gmail.com","","2018-09-03 09:47:18","","0","admin");
INSERT INTO `wp_users` VALUES("2","andyblacknredd","$P$BuDEn.TUMqUqklzFVvdR7qRII5iXIe/","andyblacknredd","andyblacknredd@gmail.com","","2018-09-18 08:46:18","","0","andyblacknredd");


DROP TABLE IF EXISTS `wp_wc_download_log`;

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_wc_webhooks`;

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES("1","color","Color","select","menu_order","0");
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES("2","size","Size","select","menu_order","0");


DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_log`;

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_items`;

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_sessions`;

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_meta`;

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_yoast_seo_meta` VALUES("4","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("5","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("6","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("7","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("8","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("9","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("10","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("11","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("12","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("13","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("14","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("15","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("16","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("17","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("18","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("19","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("20","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("21","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("22","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("23","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("24","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("25","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("26","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("27","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("28","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("29","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("30","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("31","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("54","0","0");


